x(1) = 1;
x(2) = 1/3;
n_max = 10;
for n = 3:n_max
    x(n) = 13/3*x(n-1)-4/3*x(n-2);
end
x
n = 1:n_max;
xn = (1/3).^n

if all(ismembertol(x,xn,1e-4) == 1)
    disp('Yes, It coincides with the unique solution.');
end